const NavbarData = [
  {
    id: 0,
    title: "Home",
    link: "/",
  },
  {
    id: 1,
    title: "About Us",
    link: "/about-us",
  },
  {
    id: 2,
    title: "Movies",
    link: "/movies",
  },
  {
    id: 3,
    title: "Series",
    link: "/series",
  },
  {
    id: 4,
    title: "Tw Shows",
    link: "/tv-shows",
  },
];

export default NavbarData;
