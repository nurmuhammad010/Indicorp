import React from 'react'

export default function Series() {
  return (
    <div>Series</div>
  )
}
