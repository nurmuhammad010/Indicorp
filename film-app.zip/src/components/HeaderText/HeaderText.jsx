import React from 'react'

export default function HeaderText({ children }) {
    return (
        <h1 className="header_text">{children}</h1>
    )
}
