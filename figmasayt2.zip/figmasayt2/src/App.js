import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Card from './Components/Card/Card';
import Practive from './Components/Practive/Practive';
function App() {
  return (
    <div className="App">
      <Navbar />
      <Card />
      <Practive />
    </div>
  );
}

export default App;
