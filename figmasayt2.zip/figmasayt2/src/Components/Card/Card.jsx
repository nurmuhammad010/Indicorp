import React from 'react'
import "./Card.css"
function Card() {
  return (
    <div className='cardlar' id='product'>
          <div className="typecard">
            <h3>WHY  CHOOSE US</h3>
              <span>Problems trying to resovle the conflict between the two</span>
              <span>major relms of classical pysics: Newtonian mechanics</span>
          </div>
          <div className="focard">
            <div className="focar">
              <h1>3k</h1>
              <span>CASES DONE</span>
            </div>
            <div className="focar">
              <h1>45</h1>
              <span>HAPPY CUSTOMERS</span>
            </div>
            <div className="focar">
              <h1>12+</h1>
              <span>AWARD WINNING</span>
            </div>
            <div className="focar">
              <h1>1.5k</h1>
              <span>CASES DONE</span>
            </div>
          </div>
    </div>
  
  )
}

export default Card;