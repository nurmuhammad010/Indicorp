import React from 'react'
import "./Parctivee.css"
import Business2 from "../img/Business2.jpg";
function Practive() {
  return (
    <div className='practiv' id='practive'>
            <div className="box-bottom">
             <div className="bottom-type">
                <h1>Practive Advice</h1>
                <span>Problems trying to resovle the conflict between the two</span>
              <span>major relms of classical pysics: Newtonian mechanics</span>
             </div>
             <div className="bottom-card">
              <div className="bottom-cardd">
               <div className="practiv-type">
                <h3>A single soucre of truth</h3>
                <span>Newton thought  that ligh</span>
                <span>was made up of</span>
                <span>particels, but then it</span>
                <span>was discovered</span>
                <div className="imgg">
                <img src={Business2} alt="" />
                   
                </div>
               </div>
              </div>
              <div className="bottom-cardd"></div>
              <div className="bottom-cardd"></div>
              <div className="bottom-cardd"></div>
             </div>
           </div>
    </div>
  )
}

export default Practive;